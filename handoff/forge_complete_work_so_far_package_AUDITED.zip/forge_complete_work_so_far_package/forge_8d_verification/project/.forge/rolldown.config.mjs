import { defineConfig } from "rolldown";

function forgeAliasPlugin(aliases) {
  return {
    name: "forge-aliases",
    resolveId(source) {
      if (aliases[source]) return aliases[source];
      return null;
    }
  };
}

function forgeManifestPlugin(outputPath) {
  return {
    name: "forge-manifest",
    generateBundle(_options, bundle) {
      const manifest = {};
      for (const [fileName, chunk] of Object.entries(bundle)) {
        if (chunk.type === "chunk") {
          manifest[chunk.name] = {
            fileName,
            imports: chunk.imports,
            dynamicImports: chunk.dynamicImports,
            isEntry: chunk.isEntry,
            facadeModuleId: chunk.facadeModuleId
          };
        } else {
          manifest[fileName] = { fileName, type: "asset" };
        }
      }
      this.emitFile({ type: "asset", fileName: outputPath, source: JSON.stringify(manifest, null, 2) });
    }
  };
}

function forgeSecurityPlugin(options) {
  const forbiddenPrefixes = ["ext:forge_", "forge:internal"];
  return {
    name: "forge-security-policy",
    resolveId(source, importer) {
      if (forbiddenPrefixes.some((prefix) => source.startsWith(prefix))) {
        throw new Error(`Forge security policy denied internal import ${source} from ${importer}`);
      }
      if (options.denyRemoteImports && /^(https?:|data:|blob:)/.test(source)) {
        throw new Error(`Forge security policy denied remote import ${source}`);
      }
      return null;
    },
    transform(code, id) {
      if (options.denyEval && /\beval\s*\(/.test(code)) throw new Error(`Forge security policy denied eval() in ${id}`);
      if (options.denyNewFunction && /\bnew\s+Function\s*\(/.test(code)) throw new Error(`Forge security policy denied new Function() in ${id}`);
      if (options.denyWasmEval && /WebAssembly\.(compile|instantiate)\s*\(/.test(code)) throw new Error(`Forge security policy denied dynamic WebAssembly in ${id}`);
      return null;
    }
  };
}

export default defineConfig([
  {
    input: {
      "route-blog_slug": "/mnt/data/forge_8d_verification/project/.forge/generated/routes/route-blog_slug.client.js"
    },
    platform: "browser",
    output: {
      dir: "/mnt/data/forge_8d_verification/project/.forge/static",
      format: "esm",
      sourcemap: true,
      entryFileNames: "[name].[hash].js",
      chunkFileNames: "chunks/[name].[hash].js",
      assetFileNames: "assets/[name].[hash][extname]"
    },
    treeshake: true,
    transform: {
      jsx: { runtime: "automatic", importSource: "react" },
      define: { "process.env.NODE_ENV": "\"development\"" }
    },
    plugins: [
      forgeAliasPlugin({
        "forge:data": "/mnt/data/forge_8d_verification/project/.forge/generated/internals/forge-data-runtime.js",
        "forge:cache": "/mnt/data/forge_8d_verification/project/.forge/generated/internals/forge-cache-runtime.js",
        "forge:navigation": "/mnt/data/forge_8d_verification/project/.forge/generated/internals/forge-navigation-runtime.js"
}),
      forgeManifestPlugin("forge-bundle-manifest.json"),
      forgeSecurityPlugin({ denyEval: true, denyNewFunction: true, denyWasmEval: true, denyRemoteImports: true })
    ]
  }
]);
